classdef BUF < PROBLEM
    % <single> <permutation> <large/none><constrained>
    % The traveling salesman problem
    
    %------------------------------- Reference --------------------------------
    % D. Corne and J. Knowles, Techniques for highly multiobjective
    % optimisation: some nondominated points are better than others,
    % Proceedings of the Annual Conference on Genetic and Evolutionary
    % Computation, 2007, 773-780.
    %------------------------------- Copyright --------------------------------
    % Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
    % research purposes. All publications which use this platform or any code
    % in the platform should acknowledge the use of "PlatEMO" and reference "Ye
    % Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
    % for evolutionary multi-objective optimization [educational forum], IEEE
    % Computational Intelligence Magazine, 2017, 12(4): 73-87".
    %--------------------------------------------------------------------------
    
    properties(SetAccess = private)
        R;  % Locations of points
        C;  % Adjacency matrix
    end
    methods
        %% Default settings of the problem
        function Setting(obj)
            global  wc  
            % Parameter setting
            obj.M = 1;
            if isempty(obj.D); obj.D = wc-1; end
            obj.lower    = zeros(1,obj.D);
            obj.upper    = zeros(1,obj.D)+5;
            obj.encoding = ones(1,obj.D);
        end
        %% Calculate objective values
        function PopObj = CalObj(obj,PopDec)
           global  plan Instance_all %best_buf
            DC                              =  zeros(size(PopDec,1),1);
            for i = 1 : size(PopDec,1)
                bufset                      = [0,ceil(PopDec(i,:))];
                [lineperf_temp]             = linesimulation(plan,bufset',Instance_all.Demance);
%                DC(i,1)                    = lineperf_temp.cycleTimeAverage;
                if(lineperf_temp.cycleTimeAverage>Instance_all.CT)
                DC(i,1)                     = sum(bufset)*(1+2000*(((lineperf_temp.cycleTimeAverage-Instance_all.CT)/Instance_all.CT)^2));
                else
                DC(i,1)                     = sum(bufset);
                end
            end
            PopObj(:,1) = DC;
        end
          %% Calculate constraint violations
        function PopCon = CalCon(obj,PopDec)
           PopCon       =  zeros(size(PopDec,1),1);
        end
    end
end

