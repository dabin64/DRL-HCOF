function [bufset] = buf_dqn(plan,tasktimes,CT)
global dqn

all_num = 100;
all_size = 7;

for tt = 1:size(plan,2)
    A = plan{1,tt};
    A = A(A > 0);
    workTimes(tt) = sum(tasktimes(A))/(sum(plan{1,tt}==0)+1);
    max_time(tt)  = sum(tasktimes(A))/(sum(plan{1,tt}==0)*0.98+1);
end
numBuffers = size(plan,2)-1;
bufset1 = zeros(1, numBuffers);
s5 = 1/all_size;
if numBuffers>3
    [~,laction]       = max(max_time(round(0.3*(numBuffers+1)):round(0.7*(numBuffers+1))));
    laction           = laction+round(0.3*(numBuffers+1))-2;
else
    [~,laction]       = max(max_time);
end
laction   = max (1,laction);
max_laction = laction/numBuffers;
for bufferIdx = 1:numBuffers
    % 计算相邻工位负荷
    prevLoad = workTimes(bufferIdx)   / CT;
    nextLoad = workTimes(bufferIdx+1) / CT;
    oppose_location = bufferIdx / numBuffers;%numBuffers;
    % 输入特征
    idx = bufferIdx/all_num;
    state = [ prevLoad; nextLoad; idx;oppose_location;max_laction; s5];%max_laction;
    dlState = dlarray(state, 'CB');
    
    % 利用 DQN 模型预测 Q 值，选取最大的动作对应缓冲区配置
    qValues = predict(dqn, dlState);
    [~, actionIdx] = max(extractdata(qValues));
    bufset1(bufferIdx) = actionIdx-1;
end
bufset = bufset1;
end
