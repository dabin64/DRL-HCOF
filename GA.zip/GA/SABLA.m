%计算适应度函数
classdef SABLA < PROBLEM
    % <single> <permutation> <large/none><constrained>
    % The traveling salesman problem
    
    %------------------------------- Reference --------------------------------
    % D. Corne and J. Knowles, Techniques for highly multiobjective
    % optimisation: some nondominated points are better than others,
    % Proceedings of the Annual Conference on Genetic and Evolutionary
    % Computation, 2007, 773-780.
    %------------------------------- Copyright --------------------------------
    % Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
    % research purposes. All publications which use this platform or any code
    % in the platform should acknowledge the use of "PlatEMO" and reference "Ye
    % Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
    % for evolutionary multi-objective optimization [educational forum], IEEE
    % Computational Intelligence Magazine, 2017, 12(4): 73-87".
    %--------------------------------------------------------------------------
    
    properties(SetAccess = private)
        R;  % Locations of points
        C;  % Adjacency matrix
    end
    methods
        %% Default settings of the problem
        function Setting(obj)
            global Instance_all
            % Parameter setting
            obj.M = 1;
            if isempty(obj.D); obj.D = Instance_all.Task_N; end
              obj.encoding = 5 + zeros(1,obj.D);
        end
              %% Calculate objective values 
              %% 目标值
        function PopObj = CalObj(obj,PopDec)
            global Instance_all   bestndc best_code2
            NDC                           =  zeros(size(PopDec,1),1);
            cteff                     = NDC;
            code2_all                 = cell(1,6);
            for i = 1 : size(PopDec,1)
                %PopDec是解，线平衡方案
                %更改下面的函数，适应度函数
                [DC_tmep,cteff1,code2]                    = GA_SABLA_solution_fitness(PopDec(i,:),Instance_all);
                 NDC(i,1)                       = DC_tmep;
                 cteff(i,1)                     = cteff1;
                 code2_all(i)                   = {code2};
            end
            PopObj(:,1) = NDC(:,1);
            [~,nonum] = min(PopObj(:,1));
            bestndc(end+1)                       = NDC(nonum,1);
            if bestndc(end) == min(bestndc)
                best_code2                           = code2_all{nonum};
            end
            disp(cteff(nonum,1));
        end
          %% Calculate constraint violations
        function PopCon = CalCon(obj,PopDec)
             PopCon       =  zeros(size(PopDec,1),1);
        end
    end
end

