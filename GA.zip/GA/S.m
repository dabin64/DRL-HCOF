%计算适应度函数
classdef S < PROBLEM
    % <single> <permutation> <large/none><constrained>
    % The traveling salesman problem
    
    %------------------------------- Reference --------------------------------
    % D. Corne and J. Knowles, Techniques for highly multiobjective
    % optimisation: some nondominated points are better than others,
    % Proceedings of the Annual Conference on Genetic and Evolutionary
    % Computation, 2007, 773-780.
    %------------------------------- Copyright --------------------------------
    % Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
    % research purposes. All publications which use this platform or any code
    % in the platform should acknowledge the use of "PlatEMO" and reference "Ye
    % Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
    % for evolutionary multi-objective optimization [educational forum], IEEE
    % Computational Intelligence Magazine, 2017, 12(4): 73-87".
    %--------------------------------------------------------------------------
    
    properties(SetAccess = private)
        R;  % Locations of points
        C;  % Adjacency matrix
    end
    methods
        %% Default settings of the problem
        function Setting(obj)
            global Instance_all  
            % Parameter setting
            obj.M = 1;
                if sum(Instance_all.Sort) < 6     
                    A            = ceil(6/sum(Instance_all.Sort));%复制次数
                    obj.D       = A * sum(Instance_all.Sort);
                    B            = repelem(0:Instance_all.number_model-1,Instance_all.Sort);
                    obj.lower    = repelem(B,A);
                    obj.upper    = repmat(Instance_all.Demance(1:2),1,3);
                else
                    obj.D = max(6,ceil(6/sum(Instance_all.Sort))*sum(Instance_all.Sort));
                    obj.lower   = repelem(0:Instance_all.number_model-1,Instance_all.Sort);
                    obj.upper    = Instance_all.Demance;
                end
            % Parameter setting
            obj.encoding = 7*ones(1,obj.D);
        end
              %% Calculate objective values 
              %% 目标值
        function PopObj = CalObj(obj,PopDec)
            global  plan bufset
            CTeff                            =  zeros(size(PopDec,1),1);
            for i = 1 : size(PopDec,1)
                demance                      = [ceil(PopDec(i,:))];
                CTeff1                       = linesimulation(plan,bufset,demance);
                CTeff(i,1)                   = CTeff1.cycleTimeAverage;
            end
            PopObj(:,1) = CTeff.*100;
        end
          %% Calculate constraint violations
        function PopCon = CalCon(obj,PopDec)
             PopCon       =  zeros(size(PopDec,1),1);
        end
    end
end

