%计算适应度函数
classdef S_buf < PROBLEM
    % <single> <permutation> <large/none><constrained>
    % The traveling salesman problem
    
    %------------------------------- Reference --------------------------------
    % D. Corne and J. Knowles, Techniques for highly multiobjective
    % optimisation: some nondominated points are better than others,
    % Proceedings of the Annual Conference on Genetic and Evolutionary
    % Computation, 2007, 773-780.
    %------------------------------- Copyright --------------------------------
    % Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
    % research purposes. All publications which use this platform or any code
    % in the platform should acknowledge the use of "PlatEMO" and reference "Ye
    % Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
    % for evolutionary multi-objective optimization [educational forum], IEEE
    % Computational Intelligence Magazine, 2017, 12(4): 73-87".
    %--------------------------------------------------------------------------
    
    properties(SetAccess = private)
        R;  % Locations of points
        C;  % Adjacency matrix
    end
    methods
        %% Default settings of the problem
        function Setting(obj)
            global Instance_all wc 
            % Parameter setting
            obj.M = 1;
            if isempty(obj.D); obj.D = wc-1; end
            lower1    = zeros(1,obj.D);
            upper1    = zeros(1,obj.D)+5;
            
          
                if sum(Instance_all.Sort) < 6     
                    A            = ceil(6/sum(Instance_all.Sort));%复制次数
                    D1       = A * sum(Instance_all.Sort);
                    B            = repelem(0:Instance_all.number_model-1,Instance_all.Sort);
                    lower2    = repelem(B,A);
                    upper2    = repmat(Instance_all.Demance(1:2),1,3);
                else
                    D1 = max(6,ceil(6/sum(Instance_all.Sort))*sum(Instance_all.Sort));
                    lower2    = repelem(0:Instance_all.number_model-1,Instance_all.Sort);
                    upper2    = Instance_all.Demance;
                end
                obj.lower = [lower1,lower2];
                obj.upper = [upper1,upper2];
            % Parameter setting
            obj.encoding = 6*ones(1,obj.D+D1);
        end
              %% Calculate objective values 
              %% 目标值
        function PopObj = CalObj(obj,PopDec)
            global  plan wc Instance_all
            DC                              =  zeros(size(PopDec,1),1);
            for i = 1 : size(PopDec,1)
                demance                      = [ceil(PopDec(i,wc:end))];
                bufset                       = [0,ceil(PopDec(i,1:(wc-1)))]';
                CTeff1                       = linesimulation(plan,bufset,demance);
                if(CTeff1.cycleTimeAverage>Instance_all.CT)
                DC(i,1)                     = sum(bufset)*(1+2000*(((CTeff1.cycleTimeAverage-Instance_all.CT)/Instance_all.CT)^2));
                else
                DC(i,1)                     = sum(bufset);
                % CTeff(i,1)                   = CTeff1;
                end
            end
            PopObj(:,1) = DC;
        end
          %% Calculate constraint violations
        function PopCon = CalCon(obj,PopDec)
             PopCon       =  zeros(size(PopDec,1),1);
        end
    end
end

