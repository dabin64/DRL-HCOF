%适应度函数，需要更改

%%解评估函数，得出最终成本
%函数输入：当前任务序列（solution），Instance_in--测试例子数据
%函数输出：最终成本
%改了CR，还有异常条件
function [DC_tmep,cteff1,code2]= GA_SABLA_solution_fitness(solution,Instance)
global  plan    Instance_all  wc  lineconfi bufset
    [FAST]       = seq_to_FAST(solution);
    [plan]       = line_decode1(FAST,Instance_all);

    %%获得工作站点数量
    wc = size(plan,2);

    %% 第二层
    % 用GA的方法
%     %%获得缓冲区
    % [P.decs,P.objs,P.cons]               = platemo('algorithm',@BUF_GA,'problem',@BUF,'N',5,'maxFE',20);
    % [~,Best_I]                           = min(P.objs);
    % bufset                              = [0,ceil(P.decs(Best_I,:))]';

%     % demance                             = Instance_all.Demance;


% %% 用DQN的方法%buf_Q_learning,buf_ppo,buf_dqn
      [bufset]                              = buf_dqn(plan,Instance_all.Ave_Task_time,Instance_all.CT);
      bufset                                = [0,bufset]';

% 
% % 双层编码获得缓冲区和排序分配
%     [P.decs,P.objs,P.cons]               = platemo('algorithm',@S_buf_GA,'problem',@S_buf,'N',5,'maxFE',80);
%     [~,Best_I]                           = min(P.objs);
%     bufset                              = [0,ceil(P.decs(Best_I,1:(wc-1)))]';
%     demance                             = ceil(P.decs(Best_I,wc:end));


%% 单编码排序
    % bufset                               = zeros(wc,1);

    [P.decs,P.objs,P.cons]               = platemo('algorithm',@S_GA,'problem',@S,'N',5,'maxFE',20);
    [~,Best_I]                           = min(P.objs);
    demance                              = [ceil(P.decs(Best_I,:))];
    




   %% 调用仿真ALS
    lineperf_temp            = linesimulation(plan, bufset,demance);
    cteff1                   = lineperf_temp.cycleTimeAverage;

% 各要素数量汇总
    buf                        = sum(bufset);
    WS             = sum(lineconfi(:,1));
    ever_etot       = int32(sum((lineconfi(:,3:end)~=0),2));
    Etot1           = sum(ever_etot.* lineconfi(:,1),'all');

% 缓冲区和排序储存
   code2 = [bufset(2:end)',demance];
 %%成本函数
  DCC = WS*30000+Etot1*3000+300*buf;
  if(cteff1>Instance.CT)
      DC_tmep                    = DCC*(1+20*(((lineperf_temp.cycleTimeAverage-Instance.CT)/Instance.CT)^2));
  else
      DC_tmep                    = DCC ;
  end
end