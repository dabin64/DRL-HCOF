function [bufset] = buf_Q_learning(plan,taskTimes,CT,model_name_now)
% 加载训练好的模型
% global model_name_now
% modelFileName = model_name_now;
modelFileName = 'a_Q_learning_model.mat';
nowstate = @(a,b,c)a*14*10+b*10+c;
% 加载已有模型
load(modelFileName, 'QTable');%, 'bufset', 'exampleCount'

num_wc = length(plan);

if isempty(QTable)
    error('未找到训练模型，请先运行训练模式！');
end


% 输入的前后工位的负荷比例
loadRatios_input = zeros(1,num_wc);
% for i = 1:num_wc
%     A = [plan{1,i}];
%     a = sum(A==0);
%     if  a ~= 0
%         loadRatios_input(i) = sum(taskTimes(A(A~=0)))*100/(CT*a);
%     else
%         loadRatios_input(i) = sum(taskTimes(A))*100/CT;
%     end
% end
for tt = 1:num_wc
    A = plan{1,tt};
    A = A(A > 0);
    loadRatios_input(tt) = sum(taskTimes(A))*100/((sum(plan{1,tt}==0)+1)*CT);
end
    % 计算全部工位的负荷比例编码
a = (loadRatios_input > 61);
load1(a) = floor((loadRatios_input(a)-59)/3);
load1(a==0) = 0;

% 在 Q 表中找到对应的最优缓冲区配置
bufferConfig_output = zeros(1, num_wc - 1); % 初始化缓冲区配置

for currentStation = 2:num_wc
    buf_loca = currentStation-1;
%获取位置
    if buf_loca > 29
        s3 = 10;
    else
        s3 = floor(buf_loca/3)+1;
    end
    %获取当前前后负荷
    s1 = load1(currentStation-1);
    s2 = load1(currentStation);
    % 计算当前状态
    state = nowstate( s1 , s2 , s3 ); % 当前状态由负荷比例构成
    % 获取 Q 表中当前状态的最优动作（即缓冲区大小）
    if QTable(state,:) == 0%如果没有可行的缓冲区配置，搜索最近的符合配置的缓冲区
        optimalAction = distance(state,QTable);
    else
        [~,optimalAction] = max(QTable(state,:));
    end
    bufferConfig_output(buf_loca) = optimalAction - 1; % 更新缓冲区配置
end

% 输出结果：最优缓冲区配置

bufset = bufferConfig_output;
end

%% 若没有训练数据，则搜索最近的数据
function optimalAction1 = distance(state,action)

% 目标点 (x, y)
% 获取非零元素的位置和值
x = find(sum(action,2)>0);  % rows, cols 是非零元素的位置，values 是值

% 找到最小距离的索引
[ ~ , minIdx ] = min(abs(x - state));


% 最近的非零值及其位置
[ ~ ,optimalAction1 ] = max(action(minIdx,:));

end