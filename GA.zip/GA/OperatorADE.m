function Offspring = OperatorADE(Problem,Parent1,Parent2,Parent3,Parameter)
%OperatorDE - The operator of differential evolution.
%
%   Off = OperatorDE(P1,P2,P3) uses the operator of differential evolution
%   to generate offsprings based on the parents P1, P2, and P3. If P1, P2,
%   and P3 are arrays of SOLUTION objects, then Off is also an array of
%   SOLUTION objects; while if P1, P2, and P3 are matrices of decision
%   variables, then Off is also a matrix of decision variables, i.e., the
%   offsprings are not evaluated. Each object or row of P1, P2, and P3 is
%   used to generate one offspring by P1 + 0.5*(P2-P3) and polynomial
%   mutation.
%
%	Off = OperatorDE(P1,P2,P3,{CR,F,proM,disM}) specifies the parameters of
%	operators, where CR and F are the parameters in differental evolution,
%	proM is the expectation of the number of mutated variables, and disM is
%	the distribution index of polynomial mutation.
%
%   Example:
%       Off = OperatorDE(Parent1,Parent2,Parent3)
%       Off = OperatorDE(Parent1.decs,Parent2.decs,Parent3.decs,{1,0.5,1,20})

%------------------------------- Reference --------------------------------
% H. Li and Q. Zhang, Multiobjective optimization problems with complicated
% Pareto sets, MOEA/D and NSGA-II, IEEE Transactions on Evolutionary
% Computation, 2009, 13(2): 284-302.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------


%% Parameter setting
if nargin > 4
    [CR,F,proM,disM] = deal(Parameter{:});
else
    [CR,F,proM,disM] = deal(1,0.5,1,20);
end
if isa(Parent1(1),'SOLUTION')
    evaluated = true;
    Parent1   = Parent1.decs;
    Parent2   = Parent2.decs;
    Parent3   = Parent3.decs;
else
    evaluated = false;
end
[N,D] = size(Parent1);

%% Differental evolution
Offspring       = A_sum(Parent1,RandBS(A_sub(Parent2,Parent3)));

%% Order crossover
% [N,D]     = size(Parent1);
% Offspring = [Parent1;Parent2];
k = randi(D,1,N);
for i = 1 : N
    if rand < 1
        Offspring(i,k(i)+1:end)   = setdiff(Parent1(i,:),Offspring(i,1:k(i)),'stable');
    end
end

%% Slight mutation
k = randi(D,1,N);
s = randi(D,1,N);
for i = 1 : N
    if s(i) < k(i)
        Offspring(i,:) = Offspring(i,[1:s(i)-1,k(i),s(i):k(i)-1,k(i)+1:end]);
    elseif s(i) > k(i)
        Offspring(i,:) = Offspring(i,[1:k(i)-1,k(i)+1:s(i)-1,k(i),s(i):end]);
    end
end
if evaluated
    Offspring =  Problem.Evaluation(Offspring);
end
end
 % % 抽象代数减法
 function [A_Result] = A_sub(X,Y)
 for i = 1: size(X,1)
     [B,Y_inverse]=sort(Y(i,:));
     [A_Result(i,:)] = A_sum(Y_inverse,X(i,:));
 end
 end
% % 抽象代数加法
function [A_Result] = A_sum(X,Y)
for i = 1: size(X,1)
    for j = 1: size(X,2)
        A_Result(i,j) = X(i,Y(i,j));
    end
end
end
% % RandBS
function [A_Result1] = RandBS(X)
Temp_X              = X;
for i = 1: size(X,1)
    A_Z{i,1}=[];
    A_S{i,1}=[];
end
for i = 1: size(X,1)
    for j = 1: size(X,2)-1
        if(X(i,j)>X(i,j+1))
            A_Z{i,1} = [A_Z{i,1},j];
        end
    end
end
for i = 1: size(X,1)
    while(isempty(A_Z{i,1})==false)
        select_num = randi([1 length(A_Z{i,1})],1,1);
        Temp_i = A_Z{i,1}(select_num);
        Temp_swap = Temp_X(i,Temp_i);
        Temp_X(i,Temp_i)=Temp_X(i,Temp_i+1);
        Temp_X(i,Temp_i+1)=Temp_swap;
        A_S{i,1} =[A_S{i,1},Temp_i,Temp_i+1];
        A_Z{i,1}(select_num)=[];
        if (Temp_i>1)&&(isempty(find(A_Z{i,1}==Temp_i-1)))&&(Temp_X(i,Temp_i-1)>Temp_X(i,Temp_i))
            A_Z{i,1}   = [A_Z{i,1},Temp_i-1];
        end
        if (Temp_i< size(X,2)-1)&&(isempty(find(A_Z{i,1}==Temp_i+1)))&&(Temp_X(i,Temp_i+1)>Temp_X(i,Temp_i+2))
            A_Z{i,1}   = [A_Z{i,1},Temp_i+1];
        end
    end
    if(length(A_S{i,1})<4)
        A_Result1(i,:) = X(i,:);
    else
        A_Result1(i,:) = A_Mul(A_S{i,1}(1:length(A_S{i,1})),0.5,size(X,2));
    end
end
end

% % 抽象代数乘法
function [A_Result1] = A_Mul(A_S,rate,D)
for i = 1: 1
    t  = 0;
    Secom1 =[];
    Secom2 =[];
    tru1   = [];
    if (ceil(length(A_S(i,:))*rate/2)<=1)
        cycle1   = 2;
    else
         cycle1   = ceil(length(A_S(i,:))*rate/2);
    end
        for j = 1:cycle1
            sn    = (1:D);
            t     = t + 1;
            Decom = [A_S(i,length(A_S(i,:))-2*(j-1)),A_S(i,length(A_S(i,:))-2*(j-1)-1)];
            tem_s = sn(Decom(1));
            sn(Decom(1)) =  sn(Decom(2));
            sn(Decom(2)) = tem_s;
            Secom1(t,:) = sn;
        end
    tru1        = A_sum(Secom1(1,:),Secom1(2,:));
    for k = 2 : size(Secom1,1)-1
        tru1     = A_sum(tru1,Secom1(k+1,:));
    end
    A_Result1    = tru1(i,:);
end
end