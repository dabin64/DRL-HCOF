function [bufset] = buf_ppo(plan,tasktimes,CT)
global actorNet
% 加载训练好的模型
% if exist('f1_A2C_model.mat','file')
%     load('f1_A2C_model.mat','actorNet');
%     % if exist('a_dqn_model.mat','file')
%     % load('a_dqn_model.mat','dqn');
% else
%     error('未找到训练好的模型，请先运行 dqn_train.m 进行训练。');
% end
% CTidx = find(CT_eff == taktTime)/sum(1:20);
all_num = 100;
all_size = 7;

for tt = 1:size(plan,2)
    A = plan{1,tt};
    A = A(A > 0);
    workTimes(tt) = sum(tasktimes(A))/(sum(plan{1,tt}==0)+1);
end
cv = 0.3;
numBuffers = size(plan,2)-1;
bufset1 = zeros(1, numBuffers);
for bufferIdx = 1:numBuffers
    % 计算相邻工位负荷
    prevLoad = workTimes(bufferIdx)   / CT;
    nextLoad = workTimes(bufferIdx+1) / CT;
    bufferPos = bufferIdx;
    % 输入特征
    idx = bufferIdx/all_num;
    bufsize = (bufset1(bufferIdx)+1)/all_size;
    state = [ prevLoad; nextLoad; idx; bufsize];%
    dlState = dlarray(state, 'CB');
    
    % 利用 DQN 模型预测 Q 值，选取最大的动作对应缓冲区配置
    % qValues = predict(dqn, dlState);
    % [~, actionIdx] = max(extractdata(qValues));
        testProbs = predict(actorNet, dlState);
    % actionIdx = randsample(1:11, 1, true, extractdata(testProbs)); % 概率采样
    [~, actionIdx] = max(testProbs); % 使用 argmax
    bufset1(bufferIdx) = actionIdx-1;
end
bufset = bufset1;
end
